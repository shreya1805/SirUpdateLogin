package com.lti.hackathon.exam.portal.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="optionList")
public class OptionList {
	
	@Id
	@GeneratedValue
	private int optionId;
	
	@Column(name="option_text")
	private String option;
	
	@Column(name="correct_answer")
	private String correctAnswer;
	
//	 @Override
//	public String toString() {
//		return "OptionList [optionId=" + optionId + ", option=" + option + ", correctAnswer=" + correctAnswer
//				+ ", questionBank=" + questionBank + "]";
//	}
	@ManyToOne(cascade= CascadeType.ALL)
	 @JoinColumn(name = "questionId")
	 @JsonIgnore
	 private QuestionBank questionBank;
	  
	 public int getOptionId() {
		return optionId;
	}

	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

	public String isCorrectAnswer() {
		return correctAnswer;
	}

	public void setCorrectAnswer(String correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

	public QuestionBank getQuestionBank() {
		return questionBank;
	}

	public void setQuestionBank(QuestionBank questionBank) {
		this.questionBank = questionBank;
	}

	public OptionList(int optionId,  String option,  String correctAnswer, QuestionBank questionBank) {
			
			this.optionId = optionId;
			this.option = option;
			this.correctAnswer = correctAnswer;
			this.questionBank = questionBank;
		}
	public OptionList() {
		// TODO Auto-generated constructor stub
	}

}
