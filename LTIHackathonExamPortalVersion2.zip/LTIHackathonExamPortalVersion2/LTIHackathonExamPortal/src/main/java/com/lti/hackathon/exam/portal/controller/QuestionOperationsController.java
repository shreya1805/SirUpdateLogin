package com.lti.hackathon.exam.portal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.hackathon.exam.portal.entity.QuestionBank;

import com.lti.hackathon.exam.portal.service.QuestionOperationsService;

@RestController
@CrossOrigin
public class QuestionOperationsController {

	@Autowired
	private QuestionOperationsService questionOperationsService;

	@RequestMapping(path = "/getQuestions/{domain}/{stage}", method = RequestMethod.GET)

	public List<QuestionBank> fetch(@PathVariable("domain") String domain, @PathVariable("stage") int stage) {
		return questionOperationsService.fetch(domain, stage);
	}

	@RequestMapping(path = "/questionBank", method = RequestMethod.POST)
	public String addQuestions(@RequestBody QuestionBank questionBank) {
		questionOperationsService.addQuestions(questionBank);
		return "{\"status\" : \"Added Successfully!\"}";
	}

}
