package com.lti.hackathon.exam.portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.lti.hackathon.exam.portal.entity.RegisterStudent;
import com.lti.hackathon.exam.portal.service.RegisterStudentService;

@RestController
@CrossOrigin
public class RegisterStudentController {

	@Autowired
	private RegisterStudentService registerStudentService;

	@RequestMapping(path = "/registerStudent/addInDatabase", method = RequestMethod.POST)
	public boolean registerStudentInDatabase(@RequestBody RegisterStudent registerStudent) {
		boolean flag=registerStudentService.registerStudentInDatabase(registerStudent);
		return flag;
	}
	
	@RequestMapping(path="/registerStudent/{id}", method=RequestMethod.GET)
	
	public RegisterStudent fetch(@PathVariable("id") int id) {
		return registerStudentService.fetchStudentDetails(id);
	}

}